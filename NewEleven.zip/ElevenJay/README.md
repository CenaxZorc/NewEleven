# Discord-Bot-For-Starters
This is the tutorial bot :)

## HANDLER SYLE

```js

module.exports = {
name: "ping",
usage: "Nothing rlly",
ownerOnly: false, 
cooldown: 5000,
botPermission: [],
authorPermission: [],
aliases: [],
description: "Nothing",
}

```
